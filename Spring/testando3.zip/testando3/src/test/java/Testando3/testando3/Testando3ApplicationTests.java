package Testando3.testando3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Testando3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
